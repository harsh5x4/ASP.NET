﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CreateAccount : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Calendar1.Visible = false;
    }

    protected void btncalendar_Click(object sender, EventArgs e)
    {
        Calendar1.Visible = true;
    }

    protected void Calendar_SelectionChanged(object sender, EventArgs e)
    {
        txtCreationDate.Text = Calendar1.SelectedDate.Date.ToString();
        Calendar1.Visible = false;
        dateValidator.ValueToCompare = DateTime.Today.ToString();
    }
}