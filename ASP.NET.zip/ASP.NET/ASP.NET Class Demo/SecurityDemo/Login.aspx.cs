﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;    // for Authentication

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
        //The above statement is written in web.config and hence not required here.
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //MultiView1.ActiveViewIndex = int.Parse(DropDownList1.SelectedValue);

        MultiView1.ActiveViewIndex = DropDownList1.SelectedIndex;
    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {

        //form Memebership
        //Membership.ValidateUser()


        if (FormsAuthentication.Authenticate(txtname.Text, txtpassword.Text))
        {
            FormsAuthentication.RedirectFromLoginPage(txtname.Text, CheckBox1.Checked);
        }

        else
        {
            lblError.Text = "Invalid Login Name or Password";
        }
        
    }
}