﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            //---------------By Query String------------------------------//
            //string ln = Request.QueryString["ln"];
            //if (ln==null)   // or if(string.IsNullOrEmpty(ln))
            
            //{
            //    lblLoginName.Text = "Guest";
            //}

            //else
            //{
            //    lblLoginName.Text = "Login Name:"+ ln + "Password:" + Request.QueryString["pw"];
            //}


            //-----------By Cookies------------------//
            //HttpCookie ck1 = Request.Cookies["ln"];
            //if (ck1 == null)
            //{
            //    lblLoginName.Text = "Guest";
            //}

            //else
            //{
            //    lblLoginName.Text = ck1.Value;
            //}

            LoginUser user = (LoginUser)Session["user"];
            lblLoginName.Text = user.UserFullName;

            lblNoUser.Text = Application["liveNoUsers"].ToString();
        }
    }
    protected void btnLogOut_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("Login.aspx");
    }
}



