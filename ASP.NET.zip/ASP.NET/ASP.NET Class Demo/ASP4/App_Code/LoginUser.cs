﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for LoginUser
/// </summary>
public class LoginUser
{
   

    public enum HighQualification{SSC, HSC, UnderGraduate, Graduate, PostGraduated}

    public string LoginName{get;set;}
    public string UserFullName { get; set; }
    public DateTime DOB { get; set; }
    public string Email { get; set; }
    public string Password { get; set; }
    public HighQualification HighQual { get; set; }
	

    public static List<LoginUser> GetSampleData()
    {
        List<LoginUser> users = new List<LoginUser>
        {
            new LoginUser{UserFullName="Nikhil Patel", DOB=DateTime.Now.AddMonths(254),Email="Nikhil.Patel@gmail.com",HighQual=HighQualification.UnderGraduate, LoginName="NikhilPatel",Password="pwd@NikhilPatel"},
            new LoginUser{UserFullName="Monali Das", DOB=DateTime.Now.AddMonths(274),Email="Monali.Das@gmail.com",HighQual=HighQualification.Graduate, LoginName="MonaliDas",Password="pwd@MonaliDas"},
            new LoginUser{UserFullName="Nikita Gupta", DOB=DateTime.Now.AddMonths(284),Email="Nikita.Gupta@gmail.com",HighQual=HighQualification.PostGraduated, LoginName="NikitaGupta",Password="pwd@NikitaGupta"}
        };
        return users;
    }
}