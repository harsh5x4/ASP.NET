﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //------// unobstrusiveValidationMode use the below statement //------//
       // this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        //Admin,Password

        //if(txtname.Text.Equals("Admin") && txtpassword.Text.Equals("Password"))
        //{ 
            ///// By using Query-String
            //string str = "Home.aspx?ln=" + txtname.Text + "&pw="+ txtpassword.Text;
            //Response.Redirect(str);


            ////By using Cookies
        //    HttpCookie ck1 = new HttpCookie("ln", txtname.Text);
        //    Response.Cookies.Add(ck1);
        //    Response.Redirect("Home.aspx");
        //}

        //else
        //{
        //    Response.Write("Invalid Login Name or Password.");
        //}

        List<LoginUser> loginUsers = LoginUser.GetSampleData();
        string ln = txtname.Text, pw = txtpassword.Text;

        //LINQ Query
        LoginUser user = loginUsers.SingleOrDefault(u=>u.LoginName.Equals(ln) && u.Password.Equals(pw));

        if(user!=null)
        {
            Session["user"] = user;
            Response.Redirect("Home.aspx");
        }

        else
        {
            lblError.Text = "Invalid Login Name or Password";
        }
        

    }
}