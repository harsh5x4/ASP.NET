﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Home : System.Web.UI.Page
{
    int result = 0;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        result = int.Parse(txt1.Text) + int.Parse(txt2.Text);
        ViewState["result"] = result;

    
    }
    protected void btnShow_Click(object sender, EventArgs e)
    {
        result = Convert.ToInt32(ViewState["result"]);
        lblResult.Text = result.ToString();
    }
}