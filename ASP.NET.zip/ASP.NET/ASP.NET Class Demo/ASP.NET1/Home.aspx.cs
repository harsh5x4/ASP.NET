﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        List<string> records = new List<string>();
        foreach (GridViewRow row in GridView1.Rows)
        {
            CheckBox cb1 = (CheckBox)row.Cells[7].Controls[1];
            if(cb1.Checked)
            {
               
                int rn = int.Parse(row.Cells[1].Text);
                string name = row.Cells[2].Text;
                records.Add(rn + " ," + name);
            }
        }
    }
}